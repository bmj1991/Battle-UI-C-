﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BattleModel;
using BattleDAL;
using BattleWPF;

namespace BattleWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Save(object sender, RoutedEventArgs e)
        {
            DTO_Users userObject = new DTO_Users();
            userObject.LastName = tbLastName.Text;
            userObject.FirstName = tbFirstName.Text;

            DB_42039_battleEntities db = new DB_42039_battleEntities();

            BattleDAL.user sqluser = new user();
            sqluser.firstName = userObject.FirstName;
            sqluser.lastName = userObject.LastName;

            db.users.Add(sqluser);
            db.SaveChanges();

            display.Text = "Record inserted";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

      
        private void RegisterWindow(object sender, RoutedEventArgs e)
        {
            RegisterWindow RWindow = new RegisterWindow();
            RWindow.Show();
        }

        private void Login(object sender, RoutedEventArgs e)
        {
            BattleWindow Bwindow = new BattleWindow();
            Bwindow.Show();
        }
    }
}
