﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BattleModel
{
    [DataContract]
    public class DTO_Users
    {
        [DataMember]
        public int userID { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string FirstName { get; set; }
    }

    public class DTO_Login
    {
        [DataMember]
        public int userID { get; set; }
        [DataMember]
        public string email { get; set; }
        [DataMember]
        public double latitude { get; set; }
        [DataMember]
        public double longitude { get; set; }
    }
}
