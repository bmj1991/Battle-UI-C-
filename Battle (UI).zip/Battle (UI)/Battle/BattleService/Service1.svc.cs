﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using BattleDAL;
using BattleModel;

namespace BattleService
{
    public class Service1 : IService1
    {
        // 3 example web methods.  Note they all have to appear in IService1.cs
        // When they access the database - it is all in a using {} (see below)
        // there is big difference between a DTO Class (this is a simple C# class)
        // and a SQL Object, this is why we have to convert sql objects to DTO objects

        // Each DTO Class has to have the [xxx] above class and member - see the code


        public DTO_Users GetUserInformation(DTO_Users token)
        {
            DTO_Users user = null;

            using (DB_42039_battleEntities db = new DB_42039_battleEntities())
            {
                var sqlrecord = db.users.Where(c => c.userID == token.userID).FirstOrDefault();
                if (sqlrecord != null)
                {
                    user = new DTO_Users();
                    user.FirstName = sqlrecord.firstName;
                    user.LastName = sqlrecord.lastName;
                    user.userID = sqlrecord.userID;
                }
            }
            return user;
        }

        public DTO_Users Login(DTO_Login l)
        {
            DTO_Users user = null;
            
            using (DB_42039_battleEntities db = new DB_42039_battleEntities())
            {
                // there is no column called email in the users table in SQL
                // so I used first name compared to email 
                // we will fix after email is added to the users table.

                var sqlrecord = db.users.Where(c => c.firstName.ToLower() == l.email.ToLower()).FirstOrDefault();
                if (sqlrecord != null)
                {
                    user = new DTO_Users();
                    user.FirstName = sqlrecord.firstName;
                    user.LastName = sqlrecord.lastName;
                    user.userID = sqlrecord.userID;
                }
            }
            return user;
        }

        public List<DTO_Users> GetAllUsers()
        {
            List<DTO_Users> users = new List<DTO_Users>();

            using (DB_42039_battleEntities db = new DB_42039_battleEntities())
            {
                var sqllist = db.users.OrderBy(c => c.lastName).ToList();
                if (sqllist != null)
                {
                    foreach( var r in sqllist)
                    {
                        DTO_Users user = new DTO_Users();
                        user.FirstName = r.firstName;
                        user.LastName = r.lastName;
                        user.userID = r.userID;

                        users.Add(user);
                    }
                }
            }
            return users;
        }
    }
}
