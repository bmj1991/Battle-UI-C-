﻿using BattleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace BattleService
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        DTO_Users GetUserInformation(DTO_Users token);
        [OperationContract]
        DTO_Users Login(DTO_Login token);
        [OperationContract]
        List<DTO_Users> GetAllUsers();
    }

}
