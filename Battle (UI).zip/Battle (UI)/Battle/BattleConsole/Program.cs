﻿using BattleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            DTO_Users userObject = new DTO_Users();

            userObject.FirstName = "Susie";
            userObject.LastName = "Smith";

            //Console.WriteLine(string.Format("Hello {0}",
               // userObject.FullName));

            Console.ReadLine();
        }
    }
}
